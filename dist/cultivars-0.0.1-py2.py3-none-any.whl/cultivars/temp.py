
class Temp:
    pass
